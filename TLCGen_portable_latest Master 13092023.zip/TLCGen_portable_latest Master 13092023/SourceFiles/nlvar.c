#include "nlvar.h"

mulv TNL_PAR[FCMAX];
mulv TNL_max[FCMAX];
bool TNL[FCMAX];
mulv TNL_timer[FCMAX];
