extern mulv star_programma; 
extern mulv STAR_ctijd[STARMAX];
extern mulv STAR_start1[STARMAX][FCMAX];
extern mulv STAR_eind1[STARMAX][FCMAX];
extern mulv STAR_start2[STARMAX][FCMAX];
extern mulv STAR_eind2[STARMAX][FCMAX];
