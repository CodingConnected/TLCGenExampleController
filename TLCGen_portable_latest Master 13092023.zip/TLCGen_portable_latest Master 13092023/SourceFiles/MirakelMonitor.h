int MirakelMonitor_init(char * lpWindowName);
void MirakelMonitor();

#ifdef VISSIM
int CCOL_Time_Speed_Halt = 1;
#endif