#ifndef __HALFSTARWTVH__
#define __HALFSTARWTVH__

#include "wtvfunc.h"

void max_wachttijd_halfstar(mulv twacht[], count h_plact, count pl);

#endif /* __HALFSTARWTVH__ */
