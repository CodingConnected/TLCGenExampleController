#include "starvar.h"

mulv star_programma; 
mulv STAR_ctijd[STARMAX];
mulv STAR_start1[STARMAX][FCMAX];
mulv STAR_eind1[STARMAX][FCMAX];
mulv STAR_start2[STARMAX][FCMAX];
mulv STAR_eind2[STARMAX][FCMAX];
